

setwd("/Users/Ryan/Desktop")


### 1

results = read.csv("query1.csv")

barplot(results$attempts, col=rainbow(17), ylab="Attempts", main="Attempts per Receiver", names.arg = round(as.numeric(results$rate), digits=2), xlab="Completion Rate")

legend("topright", as.character(results$player), cex=0.6, bty="n", fill=rainbow(17));




### 2


results = read.csv("query2.csv")

barplot(results$attempts, col=rainbow(10), xlab="Players", ylab="Attempts", main="Deep Balls Per Receiver")

legend("topright", as.character(results$player), cex=0.6, bty="n", fill=rainbow(10));



### 3

results = read.csv("query3.csv")

barplot(results$yards, col=rainbow(4), ylab="Yards", main="Yards per Receiver Type", names.arg = as.character(results$player))

legend("topleft", as.character(results$rate), cex=0.6, bty="n", fill=rainbow(4), title="Avg");

















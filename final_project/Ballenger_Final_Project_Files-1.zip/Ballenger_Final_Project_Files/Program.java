import org.voltdb.*;
import org.voltdb.client.*;
import java.io.*;



public class Program {

	private static String queryOne = "select Targeted_Receiver, count(*) as Attempts, avg(Reception + 0.0) as Rate from nfl where Passer = 'Tom Brady' Group By Targeted_Receiver Order By Attempts DESC;";


	private static String queryTwo = "select Targeted_Receiver, count(*) as Plays from nfl where Passer = 'Tom Brady' and Yards_Gained > 15 Group By Targeted_Receiver Order By Plays DESC;";


	private static String queryThree = "select Playmaker_Position, sum(Yards_Gained) as TotalYards, avg(Yards_Gained + 0.0) as AvgYards from nfl where Passer = 'Tom Brady' Group By Playmaker_Position;";


	private static String queryFour = "select Opp, count(*) as Deep_Balls, avg(Reception + 0.0) as Rate from nfl where Passer = 'Tom Brady' and Pass_Distance = 'Deep' Group By Opp Order By Deep_Balls DESC;";


	private static String queryFive = "select Opp, count(*) as Third_Downs, avg(Yards_Gained + 0.0) as Yardage from nfl where Passer = 'Tom Brady' and Down=3 and First_Down = 'First Down' Group By Opp;";


    private static int count = 0;




    private static void makeCSV(String contents) throws Exception{
            FileWriter writer = new FileWriter("query" + count + ".csv");

            int i = contents.indexOf("rows -");


            contents = contents.substring(i + 6);


            if(count==1) writer.append("player, attempts, rate");
            
            if(count==2) writer.append("player, attempts");

            if(count ==3) writer.append("player, yards, rate");


        
            writer.append(contents);


            writer.flush();
            writer.close();


    }


	private static void callAndPrint(org.voltdb.client.Client client, String query) throws Exception{
		ClientResponse response = client.callProcedure("@AdHoc", query);
		if (response.getStatus() != ClientResponse.SUCCESS){
    		System.err.println(response.getStatusString());
    		System.exit(-1);
		}

		 if (response.getStatus() == ClientResponse.SUCCESS) {
            VoltTable tuples = response.getResults()[0];

            //System.out.print(tuples.toString());
              // Could do something with the results.
              // For now we throw them away since we are
              // demonstrating load on the database
            tuples.resetRowPosition();
            tuples.advanceRow();
            String contents = tuples.toString();
            System.out.println(tuples.toFormattedString());


            count++;

            if(count <= 3) makeCSV(contents);

                
         }


	}


    // method main(): ALWAYS the APPLICATION entry point
    public static void main (String[] args) throws Exception {

		//String[] cmd = { "../bin/csvloader", "../bin/it.csv" };
        //Process p = Runtime.getRuntime().exec(cmd);
        //p.waitFor();

		org.voltdb.client.Client client;
        client = ClientFactory.createClient();
        client.createConnection("localhost");

        callAndPrint(client, queryOne);
        callAndPrint(client, queryTwo);
		callAndPrint(client, queryThree);
		callAndPrint(client, queryFour);
		callAndPrint(client, queryFive);
        

    }
}